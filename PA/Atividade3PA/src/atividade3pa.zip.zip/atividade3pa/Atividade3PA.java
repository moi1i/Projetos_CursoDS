
package atividade3pa;


public class Atividade3PA {

    
    public static void main(String[] args) {
       
        /*verificarNumero objverificarNumero = new verificarNumero();
        objverificarNumero.verificarN();*/
        
        /*lerTextos objlerTextos =  new lerTextos();
        objlerTextos.lerTexto();*/
        
        /*lerNome objlerNome = new lerNome();
        objlerNome.repetirNome();*/
        
        /*Crescente objCrescente = new Crescente();
        objCrescente.lerNumber();*/
        
        Inversamente objInversamente = new Inversamente();
        objInversamente.ordemInversa();
        
    }
    
}
